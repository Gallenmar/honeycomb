"""
Test for To-Do-s
"""
from sqlalchemy import text
from fastapi.testclient import TestClient
from starlette import status
from .utils import *
from src.main import app
from src.models import Todos
from src.routers.todos import get_db, get_current_user
import pytest

# Set the Dependency Overrides
app.dependency_overrides[get_db] = override_get_db
app.dependency_overrides[get_current_user] = override_get_current_user

# Get the Test Client
client = TestClient(app)

class TestToDosFunctionality:

#    @pytest.fixture
    #def test_todo(self):
        #todo = Todos(
            #title= "Learn How to Code",
            #description="Need to learn how to test",
            #priority=5,
            #complete=False,
            #user_id=1
        #)

        #db = TestingSessionLocal()
        #db.add(todo)
        #db.commit()

        #yield todo
        ## Delete the Test ToDo from db.
        #with engine.connect() as connection:
                #connection.execute(text("DELETE FROM todos;"))
                #connection.commit()


    # Test GET Methods
    def test_read_all_authenticated(self, test_todo):
        """Test we get a list of ToDos"""
        response = client.get("/")
        assert response.status_code == status.HTTP_200_OK
        assert response.json() == [{
             "complete":False,
             "title":"Learn How to Code",
             "description":"Need to learn how to test",
             "priority": 5,
             "user_id": 1,
             "id":1
        }]
    
    def test_read_one_authenticated(self, test_todo):
        """Test we get a single ToDo id based."""
        response = client.get("/todo/1")
        assert response.status_code == status.HTTP_200_OK
        assert response.json() == {
             "complete":False,
             "title":"Learn How to Code",
             "description":"Need to learn how to test",
             "priority": 5,
             "user_id": 1,
             "id":1
        }

    def test_read_one_authenticated_not_found(self, test_todo):
        """Check for a non exisitent ToDo"""
        response = client.get("/todo/999")
        assert response.status_code == 404
        assert response.json() == {"detail":"This To Do does not exist in the database"}

    # Test POST Methods
    def test_create_todo(self, test_todo):
        request_data ={
            "title":"New Todo",
            "description":"New Description",
            "priority":5,
            "complete":False
        }
        response = client.post('/todo/', json=request_data)
        assert response.status_code == 201

        db = TestingSessionLocal()
        model = db.query(Todos).filter(Todos.id == 2).first()
        assert model.title == request_data.get("title")
        assert model.description == request_data.get("description")
        assert model.priority == request_data.get("priority")

    # Test PUT Methods
    def test_update_authenticated(self, test_todo):
        """Test ToDo Update"""
        request_data={
            "title":"This is a new title",
            "description":"New Description",
            "priority":5,
            "complete":False
        }
        response = client.put('/todo/1', json=request_data)
        assert response.status_code == status.HTTP_204_NO_CONTENT

        db = TestingSessionLocal()
        model = db.query(Todos).filter(Todos.id==1).first()
        assert model.title == request_data.get("title")
        assert model.description == request_data.get("description")
        assert model.priority == request_data.get("priority")
    
    def test_update_authenticated_not_found(self, test_todo):
        """Test Update Fail on Non existent Todo"""
        request_data={
            "title":"This is a new title",
            "description":"New Description",
            "priority":5,
            "complete":False
        }
        response = client.put('/todo/999', json=request_data)
        assert response.status_code == 404
        assert response.json() == {"detail": "To Do not found in the database"}

    def test_delete_todo_authenticated(self, test_todo):
        response = client.delete("/todo/1")
        assert response.status_code == 204
        db = TestingSessionLocal()
        model = db.query(Todos).filter(Todos.id == 1).first()
        assert model is None

    def test_delete_todo_not_found_authenticated(self, test_todo):
        response = client.delete("/todo/999")
        assert response.status_code == 404
        assert response.json() == {"detail": "To Do not found in the database"}

