"""
Conftest for Pytest

"""

from src.models import Todos
from .utils import *
import pytest

@pytest.fixture
def test_todo():
    todo = Todos(
        title= "Learn How to Code",
        description="Need to learn how to test",
        priority=5,
        complete=False,
        id = 1,
        user_id=1
    )

    db = TestingSessionLocal()
    db.add(todo)
    db.commit()
    db.refresh(todo)

    try:
        yield todo
    finally:
        # Delete the Test ToDo from db.
        db.query(Todos).delete()
        db.commit()
        db.close()