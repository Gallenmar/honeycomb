"""
Test for Admin
"""
from fastapi.testclient import TestClient 
from starlette import status
from .utils import *
from src.main import app
from src.routers.admin import get_db, get_current_user
from src.models import Todos

app.dependency_overrides[get_db]= override_get_db
app.dependency_overrides[get_current_user]= override_get_current_user

client = TestClient(app)

class TestAdminFunctionality:

    def test_admin_read_all_authenticated(self, test_todo):
        response = client.get("/admin/todo")
        assert response.status_code == status.HTTP_200_OK


    def test_admin_delete_todo_authenticated(self, test_todo):
        print("test_todo.id:", test_todo.id)

        response = client.delete(f"/admin/todo/{test_todo.id}")
        print("DELETE status code:", response.status_code)
        print("DELETE response:", response.json() if response.status_code != 204 else "No content")

        assert response.status_code == status.HTTP_204_NO_CONTENT

       
