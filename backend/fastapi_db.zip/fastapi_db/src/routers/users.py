from typing import Annotated
from sqlalchemy.orm import Session
from fastapi import APIRouter, Depends, HTTPException, status
from passlib.context import CryptContext
from pydantic import BaseModel, Field
from ..database import SessionLocal
from ..models import Users
from .auth import get_current_user

# Enable routing to the Server
router = APIRouter(
    prefix='/users',
    tags=["users"]
)

# BCrypt Context
bcrypt_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class PasswordRequest(BaseModel):
    password: str
    new_password: str = Field(min_length=8)

class PhoneRequest(BaseModel):
    new_phone: str = Field(min_length=8)


# DB object.
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Dependencies
db_dependency = Annotated[Session,Depends(get_db)]
user_dependency = Annotated[dict, Depends(get_current_user)]


# Path Functions
# Get current user
@router.get("/", status_code=status.HTTP_200_OK)
async def get_users(user: user_dependency, db:db_dependency):

    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Authentication Failed")
    
    user_model = db.query(Users).filter(Users.id == user.get("id")).first()
    
    return user_model

# Update phone Number
@router.put("/phone", status_code=status.HTTP_204_NO_CONTENT)
async def update_phone(user: user_dependency, db: db_dependency, phone_request: PhoneRequest):

    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication Failed")
    
    db.query(Users)\
        .filter(Users.id==user.get("id"))\
        .update({"phone_number":phone_request.new_phone})
    db.commit()


# Update password
@router.put("/password", status_code=status.HTTP_204_NO_CONTENT)
async def change_password(user: user_dependency, db: db_dependency, password_request: PasswordRequest):

    if user is None: 
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication Failed")
    
    user_model = db.query(Users).filter(Users.id== user.get("id")).first()

    if not bcrypt_context.verify(password_request.password, user_model.hashed_password):
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Incorrect Password")
    
    db.query(Users).\
        filter(Users.id == user.get("id")).\
        update({"hashed_password":bcrypt_context.hash(password_request.new_password)})
    
    db.commit()