from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from pydantic import BaseModel
from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
from starlette import status
from passlib.context import CryptContext
from typing import Annotated
from sqlalchemy.orm import Session
from database import SessionLocal
from models import Users


router = APIRouter(
    prefix="/auth",
    tags=["auth"]
)

# Cryptography
bcrypt_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT Settings
SECRET_KEY = "secret_cat"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 30

# Database Session
def get_db():

    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# User Validation Model
class CreateUserRequest(BaseModel):
    
    email: str
    username: str
    first_name: str
    last_name: str
    password: str
    role: str

# Token Models
class Token(BaseModel):
    access_token: str
    token_type: str


# Database Dependency
db_dependency = Annotated[Session, Depends(get_db)]

# OAuth2 Bearer Scheme and dependency
oauth2_bearer = OAuth2PasswordBearer(tokenUrl="/token")

# Authenticate User
def authenticate_user(username: str, password: str, db):
    """Authenticate the user through password."""
    user = db.query(Users).filter(Users.username == username).first()
    if not user:
        return False
    
    if not bcrypt_context.verify(password, user.hashed_password):
        return False
    return user

# Create Access Token
def create_access_token(username: str, user_id: int, role: str, expires_delta: timedelta):
    encode = {"sub": username, "id": user_id, "role": role}
    expires = datetime.now(timezone.utc) + expires_delta
    encode.update({"exp":expires})
    return jwt.encode(encode, SECRET_KEY, algorithm=ALGORITHM)

# Endpoints
# Create User
@router.post('/auth/', status_code=status.HTTP_201_CREATED)
async def create_user(db: db_dependency,
                      create_user_request: CreateUserRequest):

    create_user_model = Users(
        email=create_user_request.email,
        username=create_user_request.username,
        first_name=create_user_request.first_name,
        last_name=create_user_request.last_name,
        role=create_user_request.role,
        hashed_password= bcrypt_context.hash(create_user_request.password),
        is_active=True
        
    )

    db.add(create_user_model)
    db.commit()

    return {"message": "User created successfully"}

# Login
@router.post('/token', response_model=Token)
async def logging_for_access_token(form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
                                   db: db_dependency):
    
    user = authenticate_user(form_data.username, form_data.password, db)

    if not user:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Incorrect username or password",
                            headers={"WWW-Authenticate": "Bearer"}) 
    

    # Generate the token
    token_expires = timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    token = create_access_token(user.username, user.id, user.role, token_expires)
    return {"access_token": token, "token_type": "bearer"}

# Protected Endpoint Example
@router.get('/users/me')
async def get_current_user(token: Annotated[str, Depends(oauth2_bearer)],
                           db: db_dependency):
    try: 
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        username: str = payload.get("sub")
        user_id: int = payload.get("id")
        if username is None or user_id is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, 
                                detail="Could not validate credentials.")
        
        user = db.query(Users).filter(Users.id == user_id).first()
        
        if user is None:
            raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                                detail="Could not validate credentials")
        
        return {"username": user.username, "id": user.id, "role": user.role}
    
    except JWTError:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, 
                            detail="Could not validate credentials")
