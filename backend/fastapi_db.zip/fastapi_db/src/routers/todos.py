from typing import Annotated
from sqlalchemy.orm import Session
from fastapi import APIRouter, Depends, HTTPException, Path, status
from pydantic import BaseModel, Field
from ..database import engine, SessionLocal
from ..models import Todos
from .. import models
from .auth import get_current_user

# Enable routing to the Server
router = APIRouter()


# Create the Database with a new table of ToDos.
# This is done dynamically when we run the routerlication \
# without having to use SQL queries.

# This line of code will only run if the database does not exist \
# in the directory
models.Base.metadata.create_all(bind=engine)

# DB object.
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# Dependencies
db_dependency = Annotated[Session,Depends(get_db)]
user_dependency = Annotated[dict, Depends(get_current_user)]

# Request Model for To-Dos
class TodoRequest(BaseModel):
    title: str = Field(min_length=3)
    description: str = Field(min_length=3, max_length=100)
    priority: int = Field(gt=0, lt=6)
    complete: bool
    
# Read Methods
# Get all todos ( based on user)
@router.get('/', status_code=status.HTTP_200_OK)
async def read_all(user: user_dependency,
                   db: db_dependency):
    if user is None:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication Failed"
        )
    
    return db.query(Todos).filter(Todos.user_id == user.get("id")).all()

# Get a todo by Id
@router.get('/todo/{todo_id}', status_code=status.HTTP_200_OK)
async def read_todo(user: user_dependency,
                    db: db_dependency, 
                    todo_id: int= Path(gt=0)):
    if user is None: 
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Authentication Failed")
    
    todo_model = db.query(Todos).filter(Todos.user_id==user.get("id"), Todos.id == todo_id).first()

    if todo_model is not None:
        return todo_model
    
    raise HTTPException(status_code=404, detail="This To Do does not exist in the database")


# Create Methods
# Create a Todo
@router.post('/todo', status_code=status.HTTP_201_CREATED)
async def create_todo(user: user_dependency,
                      db: db_dependency, 
                      todo_request: TodoRequest):
    
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Authentication Failed")

    todo_model = Todos(**todo_request.model_dump(), user_id=user.get("id"))
    db.add(todo_model)
    db.commit()

# Update Method
# Update the Todo 
@router.put('/todo/{todo_id}', status_code=status.HTTP_204_NO_CONTENT)
async def update_todo(user: user_dependency,
                      db: db_dependency, 
                      todo_request: TodoRequest,
                      todo_id: int = Path(gt=0)):
    
    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED,
                            detail="Authentication Failed")
    
    todo_model = db.query(Todos).filter(Todos.user_id == user.get("id"),Todos.id == todo_id).first()
    
    if todo_model is None:
        raise HTTPException(status_code=404, detail='To Do not found in the database')
    
    # Create a valid To-Do model
    todo_model.title = todo_request.title
    todo_model.description = todo_request.description
    todo_model.priority =  todo_request.priority
    todo_model.complete = todo_request.complete

    # Add To-Do to the db
    db.add(todo_model)
    db.commit()

# Delete Method
# Delete a Todo by Id
@router.delete('/todo/{todo_id}', status_code=status.HTTP_204_NO_CONTENT)
async def delete_todo(user: user_dependency,
                      db: db_dependency, 
                      todo_id: int = Path(gt=0)):

    if user is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, 
                            detail="Authentication Failed")
    
    todo_model = db.query(Todos).filter(Todos.user_id == user.get("id"),Todos.id == todo_id).first()

    if todo_model is None:
        raise HTTPException(status_code=404, detail="To Do not found in the database")
    
    db.delete(todo_model)
    db.commit()
    
    






