from fastapi import FastAPI 
from starlette import status
from .routers import auth, todos, admin, users   

# Instance of the server
app = FastAPI()

@app.get('/healthy', status_code=status.HTTP_200_OK)
def health_check():
    return {'status': 'Healthy'}

# Get the Routers
app.include_router(auth.router)
app.include_router(todos.router)
app.include_router(admin.router)
app.include_router(users.router)


