from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm import declarative_base

# Location of the Database
# I assume we have to indicate \ 
# the port of the docker container

SQLALCHEMY_DATABASE_URL='sqlite:///./todosapp.db'
#SQLALCHEMY_DATABASE_URL='postgresql://maggi:password@localhost:5432/TodoApplicationDatabase'
#SQLALCHEMY_DATABASE_URL='mysql+pymysql://maggi:meow1013@localhost:3307/TodoApplicationDatabase'


# Creates the Engine to interact with the DB.
# 
engine = create_engine(SQLALCHEMY_DATABASE_URL, )

# Keep the database session under our control:
# This should also set autocommit to False
SessionLocal = sessionmaker(autoflush=False, bind=engine)

# Create the Base
Base = declarative_base()